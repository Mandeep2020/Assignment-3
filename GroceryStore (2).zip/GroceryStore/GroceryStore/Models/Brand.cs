﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace GroceryStore.Models
{
    public class Brand
    {

        [Key]
        public int BrandId { get; set; }
        public String BrandName { get; set; }
        public String Description { get; set; }
    }
}
