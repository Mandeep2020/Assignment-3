﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GroceryStore.Data;
using GroceryStore.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace GroceryStore.Controllers
{
    public class ShopController : Controller
    {

        private readonly ApplicationDbContext _context;

        public ShopController(ApplicationDbContext context)
        {
            _context = context;
        }
        public IActionResult Index()
        {
            var brands = _context.Brand.OrderBy(b => b.BrandName).ToList();
            return View(brands);
        }
        public IActionResult Browse(string brand)
        {
            var products = _context.Product.Where(p => p.Brand.BrandName == brand).OrderBy(p => p.ProductName).ToList();
            ViewBag.brandName = brand;
            return View(products);
        }

        public IActionResult ProductDetails(string product)
        {
            var selected = _context.Product.SingleOrDefault(p => p.ProductName == product);
            return View(selected);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public  IActionResult AddToCart(int Quantity, int ProductId)
        {
            var product = _context.Product.SingleOrDefault(p => p.ProductID == ProductId);
            var price = product.Price;
            var cusername = GetUserName();
            var citem = _context.Cart.SingleOrDefault(c => c.productId == ProductId && c.Username == cusername);
            if (citem == null)
            {
                var cart = new Cart
                {
                    productId = product.ProductID,
                    Quantity = Quantity,
                    Price = price,
                    Username = cusername
                };
                _context.Cart.Add(cart);
            }
            else
            {
                citem.Quantity += Quantity;
                _context.Update(citem);
            }
            _context.SaveChanges();

            return RedirectToAction("Cart");
        }

        public IActionResult Cart()
        {
            var uname = GetUserName();
            var cart = _context.Cart.Include(c=> c.Product).Where(c => c.Username == uname).ToList();
            return View(cart);
        }
        private string GetUserName()
        {
            if (HttpContext.Session.GetString("CartUserName") == null)
            {
                var uname = "";
                if (User.Identity.IsAuthenticated)
                {
                    uname = User.Identity.Name;
                }
                else
                {
                    uname = Guid.NewGuid().ToString();
                }
                HttpContext.Session.SetString("CartUserName", uname);
            }
            return HttpContext.Session.GetString("CartUserName");

        }
        public IActionResult Delete(int id)
        {
            var citem = _context.Cart.SingleOrDefault(c => c.CartId == id);
            _context.Cart.Remove(citem);
            _context.SaveChanges();
            return RedirectToAction("Cart");
        }
        [Authorize]
        public IActionResult Checkout()
        {
            MigrateCart();
            return View();
        }

        public void MigrateCart()
        {
            if(HttpContext.Session.GetString("CartUserName") != User.Identity.Name)
            {
                var uname = HttpContext.Session.GetString("CartUserName");

                var citem = _context.Cart.Where(c => c.Username == uname);

                foreach(var item in citem)
                {
                    item.Username = User.Identity.Name;
                    _context.Update(item);
                }
                _context.SaveChanges();
                HttpContext.Session.SetString("CartUserName", User.Identity.Name);
            }
        }
        public IActionResult Payment()
        {
            return View();
        }
    }

}
