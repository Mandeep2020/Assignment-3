﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using GroceryStore.Models;

namespace GroceryStore.Data
{
    public class ApplicationDbContext : IdentityDbContext<ApplicationUser,ApplicationRole,string>
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }
        public DbSet<GroceryStore.Models.Brand> Brand { get; set; }
        public DbSet<GroceryStore.Models.Product> Product { get; set; }
        public DbSet<GroceryStore.Models.Cart> Cart { get; set; }
        public DbSet<GroceryStore.Models.Order> Order { get; set; }
    }
}
