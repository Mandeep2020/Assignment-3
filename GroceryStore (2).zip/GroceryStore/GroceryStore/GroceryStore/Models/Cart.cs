﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace GroceryStore.Models
{
    public class Cart
    {
        [Key]
        public int CartId { get; set; }
        public int productId { get; set; }
        public int Quantity { get; set; }
        public int Price { get; set; }
        public string Username { get; set; }

        public virtual Product Product { get; set; }
        
    }
}
